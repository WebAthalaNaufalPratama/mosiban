        <div class="container-fluid">
          <ul class="nav">
            <li class="nav-item">
              <a href="./" class="nav-link">
                  <i class="tim-icons icon-components"></i>
                  Home
              </a>
            </li>
            <li class="nav-item">
              <a href="./dashboard" class="nav-link">
              <i class="tim-icons icon-chart-pie-36"></i>
                Dashboard
              </a>
            </li>
            <li class="nav-item">
              <a href="./about" class="nav-link">
              <i class="tim-icons icon-atom"></i>
                Tentang Aplikasi
              </a>
            </li>
            <li class="nav-item">
              <a href="./feedback" class="nav-link">
              <i class="tim-icons icon-send text-succes"></i>
                Saran dan Masukan
              </a>
            </li>
          </ul>
          
          <div class="copyright">
            © Moban v1.0 2020
          </div>
        </div><?php /**PATH /home/u1041609/public_html/moban/MobanNew/resources/views/includes/footer.blade.php ENDPATH**/ ?>